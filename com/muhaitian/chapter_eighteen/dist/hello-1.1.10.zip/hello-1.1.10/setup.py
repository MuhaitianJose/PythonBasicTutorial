from distutils.core import setup

setup(name='hello',
      version='1.1.10',
      description='A simple example',
      author='Muhaitian',
      py_modules=['Hello']
      )
